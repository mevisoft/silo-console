const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./DeleteBucket-DsPmPBuc.js","./rolldown-runtime-BWaJ3C7D.js","./react-vendor-UL3KVrSx.js","./store-Cf_cG4qY.js","./shared-vendor-BQfq49S_.js","./shared-vendor-D-QUtJ4w.css","./lang-CiYlwSLI.js","./language-zh-y75QZXUK.js","./language-fr-BhNOGEQp.js","./language-de-C6LLOP1m.js","./language-ru-BUmxL4Ir.js","./language-es-DDzv6OKu.js","./language-pt-BR-DZGTUtUP.js","./language-ja-CQAJZ9Gy.js","./language-ar-D3xs5j4U.js","./language-tr-Xcrazw_a.js","./mds-B28KNzw0.js","./trash-DadWYzUS.js","./i18n-ldJe41lt.js","./index-BjS3YYa_.js","./ModalPresence-DQ-4YLcL.js","./preload-helper-CRzLMJPS.js","./index-CDlbreCo.css","./ConfirmDialog-BaiXVuDe.js","./ModalBox-CNftDkHF.js"])))=>i.map(i=>d[i]);
import{a as e}from"./rolldown-runtime-BWaJ3C7D.js";import{P as t,d as n,f as r,r as i,t as a}from"./react-vendor-UL3KVrSx.js";import{D as o,T as s}from"./shared-vendor-BQfq49S_.js";import{Cr as c,ar as l,r as ee}from"./store-Cf_cG4qY.js";import{i as u,m as d,n as f}from"./lang-CiYlwSLI.js";import{H as p,T as te}from"./mds-B28KNzw0.js";import{t as ne}from"./trash-DadWYzUS.js";import{t as re}from"./archive-g0MAZgFy.js";import{t as ie}from"./settings-Dp2xMr6a.js";import{t as ae}from"./folder-DJKhePq4.js";import{t as oe}from"./Tabs-YOliqYd-.js";import{a as m,n as h}from"./i18n-ldJe41lt.js";import{t as se}from"./ModalPresence-DQ-4YLcL.js";import{t as g}from"./preload-helper-CRzLMJPS.js";import{c as ce}from"./index-BjS3YYa_.js";import{t as le}from"./OverflowMenu-CsbUMgzR.js";import{t as _}from"./typography-v-iIUha0.js";import{g as ue,n as v,o as y,p as b,r as x}from"./permissions-DsoO6ayT.js";import{t as S}from"./withSuspense-DTbtEWjP.js";import{n as C}from"./SecureComponent-BSfe74Uu.js";import{t as w}from"./bucketMetadata-BAg0j77c.js";import{A as T,K as E,d as de,f as fe}from"./ConsoleKBar-Cikur0WT.js";var D=e(t()),pe=(e,t,n)=>{let r=n=>t.hasPermission(e,n),i=!t.features.includes(`object-browser-only`)&&r(x[v.BUCKETS_ADMIN_VIEW]),a=`/buckets/${encodeURIComponent(e)}/admin`;return[{id:`objects`,label:u(`Objects`),to:`/browser/${encodeURIComponent(e)}`,permitted:r(b)},{id:`summary`,label:u(`Summary`),to:`${a}/summary`,permitted:i},{id:`events`,label:u(`Events`),to:`${a}/events`,permitted:i&&r([y.S3_GET_BUCKET_NOTIFICATIONS,y.S3_PUT_BUCKET_NOTIFICATIONS,y.S3_GET_ACTIONS,y.S3_PUT_ACTIONS])},{id:`replication`,label:u(`Replication`),to:`${a}/replication`,permitted:i&&t.distributedSetup&&!n&&r([y.S3_GET_REPLICATION_CONFIGURATION,y.S3_PUT_REPLICATION_CONFIGURATION,y.S3_GET_ACTIONS,y.S3_PUT_ACTIONS])},{id:`lifecycle`,label:u(`Lifecycle`),to:`${a}/lifecycle`,permitted:i&&t.distributedSetup&&r([y.S3_GET_LIFECYCLE_CONFIGURATION,y.S3_PUT_LIFECYCLE_CONFIGURATION,y.S3_GET_ACTIONS,y.S3_PUT_ACTIONS])},{id:`access`,label:u(`Access`),to:`${a}/access`,permitted:i&&r([y.ADMIN_GET_POLICY,y.ADMIN_LIST_USER_POLICIES,y.ADMIN_LIST_USERS])},{id:`anonymous`,label:u(`Anonymous`),to:`${a}/prefix`,permitted:i&&r([y.S3_GET_BUCKET_POLICY,y.S3_GET_ACTIONS])}].filter(e=>e.permitted)},O=a(),me=S(D.lazy(()=>g(()=>import(`./DeleteBucket-DsPmPBuc.js`),__vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24]),import.meta.url))),k=s.span`
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
  a {
    color: var(--muted-foreground);
    text-decoration: none;
  }
  a:hover {
    color: var(--foreground);
  }
  > span:last-child {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
`,A=s.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  flex-wrap: wrap;
  padding: 20px 24px 12px;
  @media (max-width: 1199px) {
    padding-inline: 16px;
  }
  @media (max-width: 767px) {
    padding-inline: 12px;
    .bucketIdentity {
      flex-basis: 100%;
    }
  }
  .bucketIdentity {
    min-width: 0;
    flex: 1;
  }
  h1 {
    ${_.title} margin: 0;
    display: flex;
    align-items: center;
    gap: 8px;
    overflow-wrap: anywhere;
  }
  h1 svg {
    width: 20px;
    height: 20px;
    flex-shrink: 0;
    color: var(--muted-foreground);
  }
  .bucketActions {
    display: flex;
    align-items: center;
    gap: 8px;
  }
`,j=s.div`
  ${_.caption}
  color: var(--muted-foreground);
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  row-gap: 4px;
  column-gap: 12px;
  margin-top: 8px;
  > span {
    display: inline-flex;
    align-items: center;
    gap: 8px;
  }
  @media (min-width: 768px) {
    > span + span::before {
      content: "·";
      margin-inline-end: 4px;
    }
  }
`,M=s.div`
  min-width: 0;
  > .tabs-container {
    height: auto;
  }
  > .tabs-container > .optionsContainer {
    padding: 0 24px 12px;
    border-bottom: 1px solid var(--border);
    @media (max-width: 767px) {
      padding-inline: 12px;
    }
  }
  > .tabs-container > .tabsPanels {
    padding: 0;
  }
`;function N({bucketName:e,bucketInfo:t,primaryAction:a,refreshAction:s,onRefresh:u,anonymous:g=!1,children:_}){let v=m(),y=ce(),b=h(),x=n(),S=r(),N=de(),P=ee(c),{listing:F,visit:I,objectRoute:L,refresh:R}=fe(),[z,B]=(0,D.useState)(null),V=F?.buckets?.find(t=>t.name===e),H=t?.name===e?t:void 0,U=V||H,W=V?F?.usageUpdatedAt:void 0,G=w(U,`size`,W),K=w(U,`objects`,W),q=H?.access||V?.access,J=V?.rw_access,he=q?v(q.toLowerCase()):J?.read?J.write?v(`Read and write`):v(`Read only`):J?.write?v(`Write only`):void 0,Y=U?.creation_date?o.fromISO(U.creation_date).setLocale(d(b)):void 0,X=pe(e,N,P.enabled&&P.curSite),Z=X.find(e=>e.id===`objects`),Q=X.find(e=>e.id===`summary`),$=x.pathname.startsWith(`/browser/`),ge=$?Z?.to:x.pathname;(0,D.useEffect)(()=>{g||I(e),B(null)},[e,g,I]);let _e=[...!$&&Z?[{label:v(`Browse Bucket`),icon:(0,O.jsx)(ae,{}),onClick:()=>S(L(e))}]:[],...$&&Q?[{label:v(`Configure Bucket`),icon:(0,O.jsx)(ie,{}),onClick:()=>S(Q.to)}]:[],...!g&&C(e,ue)?[{label:v(`Delete Bucket`),icon:(0,O.jsx)(ne,{}),danger:!0,onClick:()=>B(e)}]:[]];return(0,O.jsxs)(O.Fragment,{children:[!g&&(0,O.jsx)(T,{sx:{minHeight:56},label:(0,O.jsxs)(k,{children:[(0,O.jsx)(i,{to:`/buckets`,children:v(`Buckets`)}),(0,O.jsx)(`span`,{"aria-hidden":`true`,children:`/`}),(0,O.jsx)(`span`,{children:e})]}),help:!0}),(0,O.jsxs)(A,{children:[(0,O.jsxs)(`div`,{className:`bucketIdentity`,children:[(0,O.jsxs)(`h1`,{children:[(0,O.jsx)(re,{"aria-hidden":`true`}),e]}),!g&&(0,O.jsx)(j,{children:[Y?.isValid?(0,O.jsx)(`span`,{title:Y.toLocaleString(o.DATETIME_FULL),children:f(v(`Created {date}`),{date:Y.toLocaleString(o.DATE_MED)})}):null,he||null,G===void 0?null:l(G),K===void 0?null:f(v(`{count} objects`),{count:K.toLocaleString(b)}),V&&F?.usageUpdatedAt?(0,O.jsx)(E,{at:F.usageUpdatedAt,prefix:`Calculated`}):null].filter(e=>e!==null).map((e,t)=>(0,O.jsx)(`span`,{children:e},t))})]}),(0,O.jsxs)(`div`,{className:`bucketActions`,children:[a,!y&&(0,O.jsx)(te,{id:s?.id||`refresh-bucket-info`,label:s?.label||v(`Refresh`),disabled:s?.disabled,disabledReason:s?.disabledReason,onClick:s?.onClick||(()=>{u?.(),R()}),children:(0,O.jsx)(p,{})}),(0,O.jsx)(le,{label:v(`Bucket actions`),items:[...y?[s||{label:v(`Refresh`),onClick:()=>{u?.(),R()},icon:(0,O.jsx)(p,{})}]:[],..._e]})]})]}),g?_:(0,O.jsx)(M,{children:(0,O.jsx)(oe,{horizontal:!0,useRouteTabs:!0,currentTabOrPath:ge||``,options:X.map(({id:e,label:t,to:n})=>({tabConfig:{id:e,label:v(t),to:n}})),onTabClick:t=>S(t===Z?.to?L(e):t),routes:_})}),(0,O.jsx)(se,{open:z!==null,children:z!==null&&(0,O.jsx)(me,{deleteOpen:!0,selectedBucket:z,closeDeleteModalAndRefresh:e=>{B(null),e&&(R(),S(`/buckets`))}})})]})}export{N as t};